import { ChartJSNodeCanvas } from 'chartjs-node-canvas';

const WIDTH = 1000;
const HEIGHT = 440;
const renderer = new ChartJSNodeCanvas({
  width: WIDTH,
  height: HEIGHT,
  backgroundColour: '#0b1220',
  chartCallback: (ChartJS) => {
    ChartJS.defaults.color = '#94a3b8';
    ChartJS.defaults.font.family = 'Inter, Arial, sans-serif';
  },
});

export async function generateChart(snapshot) {
  const labels = snapshot.candles.map((c) => new Date(c.openTime).toLocaleString('en-US', {
    month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: 'UTC',
  }));
  const values = snapshot.candles.map((c) => c.close);
  const positive = snapshot.changePercent >= 0;
  const lineColor = positive ? '#22c55e' : '#ef4444';

  return renderer.renderToBuffer({
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: `${snapshot.baseAsset}/USDT`,
        data: values,
        borderColor: lineColor,
        backgroundColor: `${lineColor}20`,
        borderWidth: 4,
        pointRadius: 0,
        pointHitRadius: 12,
        fill: true,
        tension: 0.28,
      }],
    },
    options: {
      responsive: false,
      animation: false,
      plugins: {
        legend: { display: false },
        title: {
          display: true,
          text: `CARDICX  •  ${snapshot.baseAsset}/USDT  •  ${snapshot.timeframe.toUpperCase()}`,
          color: '#e2e8f0',
          align: 'start',
          font: { size: 24, weight: 'bold' },
          padding: { top: 22, bottom: 28 },
        },
        tooltip: { enabled: false },
      },
      scales: {
        x: {
          grid: { color: '#1e293b', drawTicks: false },
          border: { display: false },
          ticks: { maxTicksLimit: 7, maxRotation: 0, color: '#64748b' },
        },
        y: {
          position: 'right',
          grid: { color: '#1e293b', drawTicks: false },
          border: { display: false },
          ticks: { color: '#94a3b8', callback: (value) => Number(value).toLocaleString('en-US') },
        },
      },
      layout: { padding: { left: 24, right: 28, bottom: 16 } },
    },
  });
}
