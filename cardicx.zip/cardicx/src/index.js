import 'dotenv/config';
import { Telegraf } from 'telegraf';
import { config } from './config.js';
import { registerCommands } from './bot/commands.js';
import { registerCallbacks } from './bot/callbacks.js';

if (!config.botToken) {
  throw new Error('BOT_TOKEN is missing. Copy .env.example to .env and add your Telegram bot token.');
}

const bot = new Telegraf(config.botToken);
registerCommands(bot);
registerCallbacks(bot);

bot.catch((error, ctx) => {
  console.error(`CardicX error while handling update ${ctx.update.update_id}:`, error);
});

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));

await bot.launch();
console.log('CardicX Telegram bot is running.');
