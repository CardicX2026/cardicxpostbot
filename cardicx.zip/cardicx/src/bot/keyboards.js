import { Markup } from 'telegraf';
import { config, TIMEFRAMES } from '../config.js';

export function priceKeyboard(symbol, activeTimeframe) {
  const base = symbol.replace(/USDT$/, '');
  const timeframeButtons = Object.keys(TIMEFRAMES).map((timeframe) =>
    Markup.button.callback(`${timeframe === activeTimeframe ? '✅ ' : ''}${timeframe}`, `tf:${base}:${timeframe}`),
  );
  return Markup.inlineKeyboard([
    timeframeButtons,
    [Markup.button.url(`Trade ${base}/USDT ↗`, config.tradeUrl)],
  ]);
}
