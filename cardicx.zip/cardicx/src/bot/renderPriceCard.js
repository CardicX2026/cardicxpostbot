import { Input } from 'telegraf';
import { generateChart } from '../charts/generateChart.js';
import { getFearGreed } from '../services/fearGreed.js';
import { formatPercent, formatPrice, sentimentColor } from '../utils/format.js';
import { priceKeyboard } from './keyboards.js';

function sentimentLine(sentiment) {
  if (!sentiment) return '⚪ Sentiment: Temporarily unavailable';
  const color = sentimentColor(sentiment.value);
  const marker = sentiment.value <= 24 ? '🔴' : sentiment.value <= 44 ? '🟠' : sentiment.value <= 55 ? '🟡' : '🟢';
  return `${marker} <b>Fear & Greed:</b> ${sentiment.classification} (${sentiment.value}/100)\n<a href="https://alternative.me/crypto/fear-and-greed-index/">Source: Alternative.me</a>`;
}

export async function buildPriceCard(snapshot) {
  const [photo, sentiment] = await Promise.all([generateChart(snapshot), getFearGreed()]);
  const sign = snapshot.changePercent >= 0 ? '🟢' : '🔴';
  const caption = [
    `<b>${snapshot.baseAsset}/USDT</b>  ·  <b>${snapshot.timeframe.toUpperCase()}</b>`,
    `<b>$${formatPrice(snapshot.price)}</b>  ${sign} ${formatPercent(snapshot.changePercent)}`,
    '',
    `⬆️ <b>High:</b> $${formatPrice(snapshot.high)}`,
    `⬇️ <b>Low:</b> $${formatPrice(snapshot.low)}`,
    '',
    sentimentLine(sentiment),
    '<i>Crypto market data · Not financial advice</i>',
  ].join('\n');

  return {
    media: Input.fromBuffer(photo, `cardicx-${snapshot.symbol}-${snapshot.timeframe}.png`),
    caption,
    parse_mode: 'HTML',
    reply_markup: priceKeyboard(snapshot.symbol, snapshot.timeframe).reply_markup,
  };
}
