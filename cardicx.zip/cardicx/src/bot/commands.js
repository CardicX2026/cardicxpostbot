import { buildPriceCard } from './renderPriceCard.js';
import { getMarketSnapshot } from '../services/binance.js';

export function registerCommands(bot) {
  bot.start(async (ctx) => ctx.reply('Welcome to CardicX 📈\n\nUse /p btc or /p eth to get a crypto price card.'));
  bot.help(async (ctx) => ctx.reply('Commands:\n/p <symbol> — Get a USDT market price card\nExample: /p btc'));

  bot.command('p', async (ctx) => {
    const rawSymbol = ctx.message.text.split(/\s+/)[1];
    if (!rawSymbol) return ctx.reply('Send a symbol like /p btc or /p eth.');

    const statusMessage = await ctx.reply(`Fetching ${rawSymbol.toUpperCase()} market data…`);
    try {
      const snapshot = await getMarketSnapshot(rawSymbol, '4h');
      const media = await buildPriceCard(snapshot);
      await ctx.telegram.deleteMessage(ctx.chat.id, statusMessage.message_id).catch(() => {});
      await ctx.replyWithPhoto(media.media, {
        caption: media.caption,
        parse_mode: media.parse_mode,
        reply_markup: media.reply_markup,
      });
    } catch (error) {
      await ctx.telegram.editMessageText(ctx.chat.id, statusMessage.message_id, undefined,
        error.message || 'Market data is temporarily unavailable. Please try again.').catch(() =>
        ctx.reply('Market data is temporarily unavailable. Please try again.'));
    }
  });
}
