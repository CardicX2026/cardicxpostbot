import { buildPriceCard } from './renderPriceCard.js';
import { getMarketSnapshot } from '../services/binance.js';

export function registerCallbacks(bot) {
  bot.action(/^tf:([A-Z0-9]{1,14}):(4h|12h|1d|3d|7d)$/, async (ctx) => {
    const [, baseAsset, timeframe] = ctx.match;
    const symbol = `${baseAsset}USDT`;
    await ctx.answerCbQuery('Updating price card…').catch(() => {});

    try {
      const snapshot = await getMarketSnapshot(symbol, timeframe);
      const media = await buildPriceCard(snapshot);
      await ctx.editMessageMedia({
        type: 'photo',
        media: media.media,
        caption: media.caption,
        parse_mode: media.parse_mode,
      }, { reply_markup: media.reply_markup });
    } catch (error) {
      await ctx.answerCbQuery(error.message || 'Could not update this card.', { show_alert: true }).catch(() => {});
    }
  });
}
