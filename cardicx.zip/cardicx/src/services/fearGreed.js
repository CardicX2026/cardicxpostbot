import axios from 'axios';
import { config } from '../config.js';
import { TTLCache } from '../utils/cache.js';

const cache = new TTLCache();
const KEY = 'crypto-fear-greed';

export async function getFearGreed() {
  const cached = cache.get(KEY);
  if (cached) return cached;
  try {
    const { data } = await axios.get('https://api.alternative.me/fng/', {
      params: { limit: 1, format: 'json' }, timeout: config.requestTimeoutMs,
    });
    const item = data?.data?.[0];
    const value = Number(item?.value);
    if (!Number.isInteger(value) || value < 0 || value > 100) throw new Error('Invalid Fear & Greed response');
    return cache.set(KEY, {
      value,
      classification: item.value_classification || 'Unknown',
      timestamp: Number(item.timestamp) * 1000,
    }, config.fearGreedCacheTtlMs);
  } catch {
    // Sentiment is supplemental: keep the price card working if this provider is down.
    return null;
  }
}
