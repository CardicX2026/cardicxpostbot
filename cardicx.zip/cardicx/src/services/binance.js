import axios from 'axios';
import { config, TIMEFRAMES } from '../config.js';
import { TTLCache } from '../utils/cache.js';

const cache = new TTLCache();
const http = axios.create({
  baseURL: config.binanceBaseUrl,
  timeout: config.requestTimeoutMs,
  headers: { 'User-Agent': 'CardicX-Telegram-Bot/1.0' },
});

function normalizeSymbol(input) {
  const clean = String(input || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (!clean || clean.length > 18) return null;
  return clean.endsWith('USDT') ? clean : `${clean}USDT`;
}

function friendlyApiError(error) {
  const status = error?.response?.status;
  if (status === 429 || status === 418) return new Error('Market data is rate-limited right now. Please try again shortly.');
  if (status >= 500) return new Error('The market data provider is temporarily unavailable. Please try again shortly.');
  if (error.code === 'ECONNABORTED' || error.code === 'ETIMEDOUT') return new Error('The market data provider took too long to respond. Please try again.');
  return new Error('Could not retrieve market data right now. Please try again shortly.');
}

async function getKlines(symbol, interval, limit) {
  const { data } = await http.get('/api/v3/klines', { params: { symbol, interval, limit } });
  return data.map((k) => ({
    openTime: Number(k[0]),
    open: Number(k[1]),
    high: Number(k[2]),
    low: Number(k[3]),
    close: Number(k[4]),
    closeTime: Number(k[6]),
  }));
}

export async function getMarketSnapshot(rawSymbol, timeframe) {
  const symbol = normalizeSymbol(rawSymbol);
  if (!symbol) throw new Error('Please provide a valid symbol, e.g. /p btc.');
  const tf = TIMEFRAMES[timeframe];
  if (!tf) throw new Error('Unsupported timeframe.');

  const key = `${symbol}:${timeframe}`;
  const cached = cache.get(key);
  if (cached) return cached;

  try {
    // A single-symbol ticker request plus one candle request; both are public endpoints.
    const [tickerResponse, candles] = await Promise.all([
      http.get('/api/v3/ticker/price', { params: { symbol } }),
      getKlines(symbol, tf.interval, tf.limit),
    ]);

    if (!Array.isArray(candles) || candles.length === 0) throw new Error('No candles returned');
    const selected = candles;
    if (!selected.length) throw new Error('No candles returned');

    const firstOpen = selected[0].open;
    const lastClose = selected[selected.length - 1].close;
    const changePercent = firstOpen === 0 ? 0 : ((lastClose - firstOpen) / firstOpen) * 100;
    const snapshot = {
      symbol,
      baseAsset: symbol.slice(0, -4),
      timeframe,
      timeframeLabel: tf.label,
      price: Number(tickerResponse.data.price),
      changePercent,
      high: Math.max(...selected.map((c) => c.high)),
      low: Math.min(...selected.map((c) => c.low)),
      candles: selected,
      updatedAt: Date.now(),
    };
    return cache.set(key, snapshot, config.marketCacheTtlMs);
  } catch (error) {
    if (error.message === 'No candles returned') throw new Error('That pair is not available on Binance Spot. Try another symbol, such as BTC or ETH.');
    if (error?.response?.status === 400 || error?.response?.data?.code === -1121) {
      throw new Error(`I couldn't find ${symbol}. Try a supported USDT pair, such as /p btc or /p eth.`);
    }
    if (error.message?.startsWith('Market data') || error.message?.startsWith('The market data') || error.message?.startsWith('Could not retrieve')) throw error;
    throw friendlyApiError(error);
  }
}
