export const config = {
  botToken: process.env.BOT_TOKEN,
  tradeUrl: process.env.CARDICX_TRADE_URL || 'https://example.com/trade',
  binanceBaseUrl: process.env.BINANCE_BASE_URL || 'https://data-api.binance.vision',
  marketCacheTtlMs: 15_000,
  fearGreedCacheTtlMs: 30 * 60 * 1000,
  requestTimeoutMs: 8_000,
};

export const TIMEFRAMES = {
  '4h': { interval: '5m', limit: 48, label: '4 Hours' },
  '12h': { interval: '15m', limit: 48, label: '12 Hours' },
  '1d': { interval: '1h', limit: 24, label: '1 Day' },
  '3d': { interval: '4h', limit: 18, label: '3 Days' },
  '7d': { interval: '1d', limit: 7, label: '7 Days' },
};
