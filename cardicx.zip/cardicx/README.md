# CardicX Telegram Price Bot

A Telegram crypto price-card bot built with Node.js, Telegraf, Binance public Spot market data, Chart.js, and Alternative.me's Crypto Fear & Greed Index.

## Features

- `/p <symbol>` command, e.g. `/p btc`, `/p eth`
- USDT pairs from Binance Spot
- Dark CardicX-branded chart image
- Current price, selected-period change, high and low
- Crypto Fear & Greed score with a coloured emoji marker
- Inline timeframe buttons: 4h, 12h, 1d, 3d, 7d
- Timeframe selection edits the existing photo message
- 15-second market-data cache and 30-minute sentiment cache
- Friendly unknown-symbol and upstream-error handling
- Works in private chats and groups

## Requirements

- Node.js 20+
- A Telegram bot token from [@BotFather](https://t.me/BotFather)

## Setup

```bash
npm install
cp .env.example .env
```

Put your token in `.env`:

```env
BOT_TOKEN=123456:your-token
CARDICX_TRADE_URL=https://your-cardicx-site.example
BINANCE_BASE_URL=https://data-api.binance.vision
```

Replace `CARDICX_TRADE_URL` with the final URL Alex supplies. The trade button currently opens that URL as-is; it does not append a symbol query parameter.

Start the bot:

```bash
npm start
```

For development with automatic restart:

```bash
npm run dev
```

## Commands

- `/start` — welcome message
- `/help` — command help
- `/p btc` — Bitcoin price card
- `/p@YourBotUsername eth` — works in groups when addressing the bot explicitly

In groups, disable BotFather privacy mode if you want the bot to see ordinary group messages. For slash commands, Telegram can route `/p@YourBotUsername` while privacy mode remains enabled.

## Market data and calculations

- Binance public market-data-only REST API: `https://data-api.binance.vision`
- Candles: `GET /api/v3/klines`
- Current price: `GET /api/v3/ticker/price`
- The chart samples each selected window at a suitable candle interval: 5m candles for 4h, 15m for 12h, 1h for 1d, 4h for 3d, and daily candles for 7d.
- Change is calculated from the first selected candle's open to the latest selected candle's close. Current price is fetched separately, so the percentage is the selected candle-window change, not the 24-hour ticker change.
- High and low are the maximum candle high and minimum candle low in the selected window.
- Market data is cached per symbol/timeframe for 15 seconds. Fear & Greed is cached for 30 minutes because it updates daily.

## Important provider notes

Binance documents public market-data-only endpoints that do not require an API key. Its REST API uses IP-based request-weight limits. The bot caches market data, uses request timeouts, and returns a friendly message on 429/418 or provider failures; do not remove backoff behaviour if you add retries.

Alternative.me's Crypto Fear & Greed API is `https://api.alternative.me/fng/`. Its rules allow commercial use when the source is prominently acknowledged next to the displayed data. The card therefore includes a linked `Source: Alternative.me` attribution beside the sentiment reading. Review provider terms again before production launch.

## Deployment

Deploy on a Node.js host (VPS, Render, Railway, etc.). Set `BOT_TOKEN` and `CARDICX_TRADE_URL` as environment variables in the host dashboard. Do not commit `.env` or your bot token.

Use a single running bot instance for long polling. If you later scale horizontally, switch to Telegram webhooks and add a shared cache such as Redis so all instances share the same market cache.

## Notes / next improvements

- Add Redis for shared caching if running multiple instances.
- Add a `/symbols` or `/top` command if needed.
- Consider a provider fallback if Binance market-data access is unavailable in your deployment region.
- The Fear & Greed score is a broad crypto/Bitcoin sentiment indicator, not a coin-specific sentiment score or a trading signal.
